


/**套餐绑定关系查询8076160*/
public class RequestParam8076160{
/** 套餐加办流水 备注:*/
public int D44_70_PACKETSEQ;
}


