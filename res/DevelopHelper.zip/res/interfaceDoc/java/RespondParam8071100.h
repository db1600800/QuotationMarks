


#import <Foundation/Foundation.h>
/*订单生成8071100*/
@interface RespondParam8071100:NSObject
/* 订单号 备注:*/
@property ( nonatomic) NSString *I_ORDER_NO ;
@end


