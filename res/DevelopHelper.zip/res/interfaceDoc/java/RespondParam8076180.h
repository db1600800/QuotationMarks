


#import <Foundation/Foundation.h>
/*套餐绑定撤销8076180*/
@interface RespondParam8076180:NSObject
/*  备注:*/
@property ( nonatomic) NSString *;
/*  备注:*/
@property ( nonatomic) NSString *;
@end


