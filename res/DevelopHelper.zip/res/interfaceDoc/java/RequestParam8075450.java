


/**套餐明细查询8075450*/
public class RequestParam8075450{
/** 套餐号 备注:3*/
public String D44_70_PACKETID;
/**  备注:*/
public String ;
/**  备注:*/
public String ;
/**  备注:*/
public String ;
}


