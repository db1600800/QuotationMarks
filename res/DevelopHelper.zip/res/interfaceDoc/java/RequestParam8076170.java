


/**套餐绑定加办8076170*/
public class RequestParam8076170{
/** 会员号 备注:12 2010-11-15新增*/
public String D44_70_CUSTMNUM;
/** 套餐加办流水 备注:*/
public int D44_70_PACKETSEQ;
/** 套餐代号 备注:3*/
public String D44_70_PACKETID;
/** 循环域结束 备注:*/
public String ;
/**  备注:*/
public String ;
/**  备注:*/
public String ;


/** 循环域开始 备注:*/
public int D44_70_RECORDNUM1;
/** 绑定对象类型 备注:2*/
public String D44_70_BIND_TYPE[];
/** 绑定标志一 备注:40*/
public String D44_70_BIND_OBJECT1[];
/** 绑定标志二 备注:40*/
public String D44_70_BIND_OBJECT2[];
}


