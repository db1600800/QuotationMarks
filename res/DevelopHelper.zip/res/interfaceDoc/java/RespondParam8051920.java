


/**支付方式查询 8051920*/
public class RespondParam8051920{
/** 循环域结束 备注:*/
public String ;
/**  备注:*/
public String ;


/** 循环域开始 备注:*/
public int recodeNum;
/** 支付方式 备注:M*/
public String B60_PAY_TYPE;
/** 支付方式名称 备注:M*/
public String B05_ORIE_MODE;
}


