


/**支付方式查询 8051920*/
public class RequestParam8051920{
/** 业务代码 备注:M*/
public String I_BUSI_NO ;
/** 渠道标示 备注:C*/
public String I_CHANNEL_NO;
}


