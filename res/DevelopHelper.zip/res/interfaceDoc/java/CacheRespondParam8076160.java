


/**套餐绑定关系查询8076160*/
public class CacheRespondParam8076160{
/** 循环域结束 备注:*/
public String ;
/** 循环域结束 备注:*/
public String ;
/**  备注:*/
public String ;


/** 循环域开始 备注:循环一*/
public int D44_70_RECORDNUM;
/** 绑定对象类型 (数组)备注:2*/
public String D44_70_BIND_TYPE[];
/** 最大绑定值 (数组)备注:*/
public int D44_70_MAX_BINDNUM[];
/** 绑定实际值 (数组)备注:*/
public int D44_70_BIND_REALNUM[];


/** 循环域开始 备注:循环二*/
public int D44_70_RECORDNUM1;
/** 绑定对象类型 (数组)备注:2*/
public String D44_70_BIND_TYPE_BAK[];
/** 绑定标志一 (数组)备注:40*/
public String D44_70_BIND_OBJECT1[];
/** 绑定标志二 (数组)备注:40*/
public String D44_70_BIND_OBJECT2[];
}


