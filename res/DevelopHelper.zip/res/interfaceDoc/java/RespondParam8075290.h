


#import <Foundation/Foundation.h>
/*会员订单预览8075290*/
@interface RespondParam8075290:NSObject
/* 业务开办局 备注:*/
@property ( nonatomic) NSString *D44_70_YWKBJ;
/*  备注:*/
@property ( nonatomic) NSString *;
/* 商户号 备注:*/
@property ( nonatomic) NSString *B82_STORE_NO;
/* 记账商品号 备注:*/
@property ( nonatomic) NSString *B87_MERCH_ID;
/* 记账商品名称 备注:*/
@property ( nonatomic) NSString *I_MERCH_NAME;
/* 客户编号 备注:*/
@property ( nonatomic) NSString *I_CSTM_NO;
/* 客户姓名 备注:*/
@property ( nonatomic) NSString *I_CSTM_NAME ;
/* 客户联系电话 备注:*/
@property ( nonatomic) NSString *B87_TELE_NO;
/* 客户联系地址 备注:*/
@property ( nonatomic) NSString *I_CSTM_ADDR;
/* 客户联系邮编 备注:*/
@property ( nonatomic) NSString *B30_CSTM_ZIP;
/* 收件人姓名 备注:*/
@property ( nonatomic) NSString *I_RCVR_NAME;
/* 收件人电话 备注:*/
@property ( nonatomic) NSString *I_RCVR_TEL;
/* 收件人地址 备注:*/
@property ( nonatomic) NSString *I_RCVR_ADDR;
/* 收件人邮编 备注:*/
@property ( nonatomic) NSString *I_RCVR_POST;
/* 收件人要求到达日期 备注:*/
@property ( nonatomic) NSString *I_RCVR_DATE;
/* 收件人要求到达时间 备注:*/
@property ( nonatomic) NSString *I_RCVR_TIME;
/* 支付金额1 备注:*/
@property ( nonatomic) float I_AMT1;
/* 支付金额2 备注:*/
@property ( nonatomic) float I_AMT2;
/* 支付金额3 备注:*/
@property ( nonatomic) float I_AMT3;
/* 支付金额4 备注:*/
@property ( nonatomic) float I_AMT4;
/* 支付金额5 备注:*/
@property ( nonatomic) float I_AMT5;
/* 业务种类 备注:*/
@property ( nonatomic) NSString *I_BUSI_NO ;
/*  备注:*/
@property ( nonatomic) NSString *;
/* 总业务金额 备注:*/
@property ( nonatomic) float B00_CASH_AMT;
/* 业务手续费 备注:*/
@property ( nonatomic) float B04_FEE2;
/* 配送费 备注:*/
@property ( nonatomic) float B60_MAIL_FEE;
/* 优惠手续费 备注:*/
@property ( nonatomic) float B60_BATE_FEE ;
/* 预多滞纳金 备注:*/
@property ( nonatomic) float B60_DEST_FEE ;
/* 合计费用 备注:*/
@property ( nonatomic) float B60_TOTAL_FEE;
/* 附加费 备注:*/
@property ( nonatomic) float B60_OIL_FEE;
/* 收货人所在城市 备注:*/
@property ( nonatomic) NSString *B04_TRANBRANCH;
/* 收货人所在城市 备注:*/
@property ( nonatomic) NSString *B04_TRANBRANCH;
/* 客户反馈方式 备注:*/
@property ( nonatomic) NSString *B05_DEAL_TYPE;
/* 订单回音途径 备注:*/
@property ( nonatomic) NSString *B13_HJJE_CAP;
/* 客户资料描述 备注:*/
@property ( nonatomic) NSString *B60_MESS_SUB;
/* 备注 备注:*/
@property ( nonatomic) NSString *B87_REMARK;
/*  备注:*/
@property ( nonatomic) NSString *;
/* 应收金额 备注:*/
@property ( nonatomic) float B04_BALANCE2;
/*  备注:*/
@property ( nonatomic) NSString *;
/* 循环域结束 备注:*/
@property ( nonatomic) NSString *;
/* 循环域结束 备注:*/
@property ( nonatomic) NSString *;
/* 异地交易标志 备注:*/
@property ( nonatomic) NSString *D44_70_YIDI_FLAG;
/* 优惠手续费 备注:*/
@property ( nonatomic) float B60_SOFT_UP;
/* 优惠配送费 备注:*/
@property ( nonatomic) float B60_SOFT_DOWN;
/*  备注:*/
@property ( nonatomic) NSString *;


/* 循环域开始 备注:*/
@property ( nonatomic) int B04_MAX_RECORD;
/* 商品代码（记订单明细用） 备注:*/
@property ( nonatomic) NSString *I_MERCH_ID;
/* 商品名称（记订单明细用） 备注:*/
@property ( nonatomic) NSString *B82_MERCH_NAME;
/* 商品数量（记订单明细用） 备注:*/
@property ( nonatomic) int B04_REC_NUM;
/* 商品价格 备注:*/
@property ( nonatomic) float B82_MERCH_PRICE;
/* 商品优惠后价格 备注:*/
@property ( nonatomic) float B82_PREFER_PRICE;
/* 客户代号 备注:*/
@property ( nonatomic) NSString *D44_70_CUSTMNUM;
/* 套餐号 备注:*/
@property ( nonatomic) NSString *D44_70_PACKETID;
/* 商品备注1 备注:*/
@property ( nonatomic) NSString *B50_ORDER_REMARK;
/* 商品备注2 备注:*/
@property ( nonatomic) NSString *B60_REMARK2;
/* 业务相关资料描述 备注:*/
@property ( nonatomic) NSString *B50_SALE_MSG;
/* 关联优惠流水 备注:*/
@property ( nonatomic) int D44_70_SEQNO;
/* 优惠金额 备注:*/
@property ( nonatomic) float D44_70_MONEY1;


/* 循环域开始 备注:*/
@property ( nonatomic) int B13_ENTR_FP_NUM;
/* 业务基本费用 备注:*/
@property ( nonatomic) float B89_PAY_SUM;
/* 基本滞纳金 备注:*/
@property ( nonatomic) float B60_LOTT_AMT3;
/* 预多收滞纳金 备注:*/
@property ( nonatomic) float B60_LOTT_AMT5;
/* 优惠配送费 备注:*/
@property ( nonatomic) float B60_LOTT_AMT4;
/* 实收配送费 备注:*/
@property ( nonatomic) float B05_BALANCE;
@end


