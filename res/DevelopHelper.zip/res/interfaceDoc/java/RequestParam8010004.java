


/**可办理套餐查询8010004*/
public class RequestParam8010004{
/** 套餐名称 备注:40*/
public String D44_70_PACKETNAME;
/** 排序方式 备注:201：价格从高倒地02：价格从低到高*/
public String D44_70_FIELD_SORTID;
/** 服务周期 备注:201：1个月02：3个月03：6个月04：12个月*/
public String D44_70_CODE_TYPE;
/** 服务区域城市代号 备注:15*/
public String D44_70_CITYCOE;
/**  备注:*/
public String ;
/** 页码 备注:*/
public int D44_70_PAGENUM;
/** 页码大小 备注:*/
public int D44_70_PAGECODE;
/**  备注:*/
public String ;
}


