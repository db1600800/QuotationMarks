
#import "RespondParam8071100.h"
@implementation RespondParam8071100
/* 订单号 备注:*/
@synthesize I_ORDER_NO ;
@end

