


/**会员已购买套餐查询8075600*/
public class RequestParam8075600{
/** 会员号 备注:*/
public String D44_70_CUSTMNUM;
/** 查询范围 备注:0：有效套餐1:过期套餐2：未启用套餐3：所有套餐*/
public String D44_70_VALID;
/** 页码 备注:*/
public int D44_70_PAGENUM;
/** 页码大小 备注:*/
public int D44_70_PAGECODE;
}


