


/**套餐绑定加办8076170*/
public class RespondParam8076170{
/** 套餐加办流水 备注:*/
public int D44_70_PACKETSEQ;
/**  备注:*/
public String ;
}


