


#import <Foundation/Foundation.h>
/*会员已购买套餐查询8075600*/
@interface RespondParam8075600:NSObject
/* 总记录数 备注:*/
@property ( nonatomic) int D44_70_MAXRECORD;
/* 重复域开始 备注:*/
@property ( nonatomic) int D44_70_RECORDNUM;
/* 套餐加办流水 备注:*/
@property ( nonatomic) int D44_70_SEQNO;
/* 套餐号 备注:*/
@property ( nonatomic) NSString *D44_70_PACKETID;
/* 套餐名 备注:*/
@property ( nonatomic) NSString *D44_70_PACKETNAME;
/* 起始有效期 备注:*/
@property ( nonatomic) NSString *D44_70_BEGINDATE;
/* 截止有效期 备注:*/
@property ( nonatomic) NSString *D44_70_ENDDATE;
/* 套餐加办日期 备注:*/
@property ( nonatomic) NSString *D44_70_TRAN_DATE;
/* 套餐绑定内容 备注:*/
@property ( nonatomic) NSString *D44_70_BIG_DESC;
/* 套餐状态 备注:*/
@property ( nonatomic) NSString *D44_70_NEW_STATUS;
/* 重复域结束 备注:*/
@property ( nonatomic) NSString *;
@end


