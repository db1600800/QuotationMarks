
#import "RespondParam4453020.h"
@implementation RespondParam4453020
/* 查询结果总记录数 备注:满足条件的总记录数*/
@synthesize B30_ZF_NUM;
@end

