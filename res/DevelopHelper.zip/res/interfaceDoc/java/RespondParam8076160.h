


#import <Foundation/Foundation.h>
/*套餐绑定关系查询8076160*/
@interface RespondParam8076160:NSObject
/* 循环域结束 备注:*/
@property ( nonatomic) NSString *;
/* 循环域结束 备注:*/
@property ( nonatomic) NSString *;
/*  备注:*/
@property ( nonatomic) NSString *;


/* 循环域开始 备注:循环一*/
@property ( nonatomic) int D44_70_RECORDNUM;
/* 绑定对象类型 备注:2*/
@property ( nonatomic) NSString *D44_70_BIND_TYPE;
/* 最大绑定值 备注:*/
@property ( nonatomic) int D44_70_MAX_BINDNUM;
/* 绑定实际值 备注:*/
@property ( nonatomic) int D44_70_BIND_REALNUM;


/* 循环域开始 备注:循环二*/
@property ( nonatomic) int D44_70_RECORDNUM1;
/* 绑定对象类型 备注:2*/
@property ( nonatomic) NSString *D44_70_BIND_TYPE_BAK;
/* 绑定标志一 备注:40*/
@property ( nonatomic) NSString *D44_70_BIND_OBJECT1;
/* 绑定标志二 备注:40*/
@property ( nonatomic) NSString *D44_70_BIND_OBJECT2;
@end


