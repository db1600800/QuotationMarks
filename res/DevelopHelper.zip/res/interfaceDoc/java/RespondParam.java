


/**     退款单明细查询 */
public class RespondParam{
/** 查询结果总记录数 备注:满足条件的总记录数*/
public int B30_ZF_NUM;
}


