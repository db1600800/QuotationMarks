


#import <Foundation/Foundation.h>
/*退款单批量查询 4453020*/
@interface RespondParam4453020:NSObject
/* 查询结果总记录数 备注:满足条件的总记录数*/
@property ( nonatomic) int B30_ZF_NUM;
@end


