


#import <Foundation/Foundation.h>
/*套餐绑定加办8076170*/
@interface RespondParam8076170:NSObject
/* 套餐加办流水 备注:*/
@property ( nonatomic) int D44_70_PACKETSEQ;
/*  备注:*/
@property ( nonatomic) NSString *;
@end


