


/**退款单批量查询 4453020*/
public class CacheRespondParam4453020{
/** 查询结果总记录数 备注:满足条件的总记录数*/
public int B30_ZF_NUM;
}


