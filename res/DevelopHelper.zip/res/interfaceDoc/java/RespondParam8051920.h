


#import <Foundation/Foundation.h>
/*支付方式查询 8051920*/
@interface RespondParam8051920:NSObject
/* 循环域结束 备注:*/
@property ( nonatomic) NSString *;
/*  备注:*/
@property ( nonatomic) NSString *;


/* 循环域开始 备注:*/
@property ( nonatomic) int recodeNum;
/* 支付方式 备注:M*/
@property ( nonatomic) NSString *B60_PAY_TYPE;
/* 支付方式名称 备注:M*/
@property ( nonatomic) NSString *B05_ORIE_MODE;
@end


