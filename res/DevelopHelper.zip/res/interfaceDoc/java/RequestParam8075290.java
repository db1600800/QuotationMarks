


/**会员订单预览8075290*/
public class RequestParam8075290{
/** 会员号 备注:*/
public String B07_CSTM_NO;
/** 循环域结束 备注:*/
public String ;
/** 支付方式 备注:*/
public String D44_70_PAY_MODE;
/**  备注:*/
public String ;


/** 循环域开始 备注:*/
public int B04_MAX_RECORD;
/** 加办标志 备注:*/
public String D44_70_FLAG_JB[];
/** 原套餐加办流水号 备注:*/
public int D44_70_CARID[];
/** 套餐号 备注:*/
public String B22_QH[];
/** 加办流水号 备注:*/
public int D44_70_PACKETSEQ[];
/** 指定起始日期 备注:*/
public String D44_70_BEGINDATE[];
/** 指定截止日期 备注:*/
public String D44_70_ENDDATE[];
}


