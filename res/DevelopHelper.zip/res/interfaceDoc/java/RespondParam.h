


#import <Foundation/Foundation.h>
/*     退款单明细查询 */
@interface RespondParam:NSObject
/* 查询结果总记录数 备注:满足条件的总记录数*/
@property ( nonatomic) int B30_ZF_NUM;
@end


