
#import "RespondParam8076170.h"
@implementation RespondParam8076170
/* 套餐加办流水 备注:*/
@synthesize D44_70_PACKETSEQ;
/*  备注:*/
@synthesize ;
@end

