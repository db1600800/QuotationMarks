


/**订单生成8071100*/
public class RespondParam8071100{
/** 订单号 备注:*/
public String I_ORDER_NO ;
}


