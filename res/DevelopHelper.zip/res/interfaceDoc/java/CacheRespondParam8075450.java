


/**套餐明细查询8075450*/
public class CacheRespondParam8075450{
/** 套餐号 备注:3*/
public String D44_70_PACKETID;
/** 套餐名称 备注:40*/
public String D44_70_PACKETNAME;
/** 套餐描述 备注:100*/
public String D44_70_DESC;
/** 套餐状态 备注:10 有效  1无效*/
public String D44_70_PACKET_STATUS;
/** 套餐修改模式 备注:2*/
public String D44_70_PACKET_MODIFY_MODE;
/** 客户对象标志 备注:1*/
public String D44_70_CSTMPACK_OBJECT;
/** 套餐累加模式 备注:1*/
public String D44_70_CSTMPACK_COUNT_MODE;
/** 套餐最大累加金额 备注:*/
public int D44_70_TOTALMONEY;
/** 套餐地域模式 备注:1*/
public String D44_70_CSTMPACK_AREA_MODE;
/** 套餐计费模式 备注:1*/
public String D44_70_PACKET_MODE;
/** 套餐计费周期 备注:*/
public int D44_70_CSTMPACK_FEE_PERIOD;
/** 周期收费标准 备注:*/
public int D44_70_MONEY1;
/** 商品代号 备注:20*/
public String D44_70_MERCH_ID;
/** 套餐有效起始日 备注:8 2011-2-15新增*/
public String D44_70_BEGINDATE;
/** 套餐有效结束日 备注:8 2011-2-15新增*/
public String D44_70_ENDDATE;
/** 循环域结束 备注:*/
public String ;
/** 循环域结束 备注:*/
public String ;
/** 循环域结束 备注:*/
public String ;
/**  备注:*/
public String ;


/** 循环域开始 备注:循环域1*/
public int D44_70_RECORDNUM;
/** 覆盖市局 (数组)备注:8*/
public String D44_70_CITYBRCH[];
/** 市局名称 (数组)备注:50*/
public String D44_70_NAME1[];


/** 循环域开始 备注:循环域2*/
public int D44_70_RECORDNUM1;
/** 业务代号 (数组)备注:4*/
public String D44_70_BUSI_ID[];
/** 异地交易标志 (数组)备注:1*/
public String D44_70_YIDI_FLAG[];
/** 最大次数 (数组)备注:*/
public int D44_70_NUM[];
/** 是否累计金额 (数组)备注:1*/
public String D44_70_FLAG_COUNT_MONEY[];


/** 循环域开始 备注:循环域3*/
public int D44_70_RECORDNUM2;
/** 绑定对象类型 (数组)备注:2*/
public String D44_70_BIND_TYPE[];
/** 最大绑定值 (数组)备注:*/
public int D44_70_MAX_BINDNUM[];
}


