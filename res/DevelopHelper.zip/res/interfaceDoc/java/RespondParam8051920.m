
#import "RespondParam8051920.h"
@implementation RespondParam8051920
/* 循环域结束 备注:*/
@synthesize ;
/*  备注:*/
@synthesize ;
/* 循环域开始 备注:*/
@synthesize recodeNum;
/* 支付方式 备注:M*/
@synthesize B60_PAY_TYPE;
/* 支付方式名称 备注:M*/
@synthesize B05_ORIE_MODE;
@end

